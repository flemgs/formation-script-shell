#!/bin/bash

# Compte le nombre de fichiers et de repertoires

while (($# != 0)); do
  echo $*
  shift
done
