#!/bin/bash

# Cherche un fichier dans un repertoire


if test $# -gt 2
then
  echo -e "Erreur: Plus que 2 arguments saisis: $# \n $*"
  echo -e "Usage: $(basename $0) [file] [rep]\n"
  exit 1
fi

if test $# -eq 0
then 
  read -p "Veuillez saisir le nom du repertoire : " rep
  read -p "Veuillez saisir le nom du fichier : " fic
elif test $# -eq 1
then
  fic="$1"
  read -p "Veuillez saisir le nom du repertoire : " rep
else
  fic="$1"
  rep="$2"	
fi

test -d "$rep" || {
  echo -e "Erreur: Le repertoire "$rep" n'existe pas\n"
  exit 1
}

find "$rep" -name "$fic" 2> /dev/null

echo
