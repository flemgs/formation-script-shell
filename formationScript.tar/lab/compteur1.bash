#!/bin/bash

# Compte le nombre de fichiers et de repertoires

nRep=0
nFic=0

for element in $(ls)
do
  if test -d "$element"
  then
    ((nRep++))
  elif test -f "$element"
  then
    ((nFic++))
  fi
done

echo -e "Il y a $nFic fichier(s) et $nRep repertoire(s) dans le dossier courant.\n"
