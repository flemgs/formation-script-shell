#!/bin/bash

hello="you"

essai() {
  echo "Bonjour!"
  hello="me"
  echo "fonction $hello"
  return 1
}

echo $?
echo $hello

sol=$(essai)
echo $?
echo $hello

echo $sol
echo $hello
