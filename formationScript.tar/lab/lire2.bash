#!/bin/bash

# Lis les lignes d'un fichier

OLD_IFS="$IFS"

while read ligne
do
  IFS=":@"
  set $ligne
  echo "$1 habite a $5"
  IFS="$OLD_IFS"
done < liste
