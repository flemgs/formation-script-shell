#!/bin/bash

PS3="Votre choix: "

select choix in quitter $(ls)
do
  case $choix in
    quitter) break
             ;;
    *) echo "Traitement de $choix"
             ;;
  esac
  break
done
