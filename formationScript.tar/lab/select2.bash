#!/bin/bash

. ./intro.bash

PS3="Votre choix: "

while true
do
  affichage "Menu"
  select choix in quitter $(ls)
  do
    case $choix in
      quitter) 
        echo "Fermeture du programme."
        exit 0
        ;;
      *) affichage $choix
        ;;
    esac
    break
  done
  read -p "Appuyer sur la touche entree pour continuer."
done


