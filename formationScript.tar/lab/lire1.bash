#!/bin/bash

# Lis les lignes d'un fichier
OLD_IFS="$IFS"

while read ligne
do
  IFS=":"
  set $ligne
  echo "Login: $1 et UID: $3"
  IFS="$OLD_IFS"
done < /etc/passwd
