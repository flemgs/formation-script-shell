#!/bin/bash

# Compte le nombre de fichiers et de repertoires

nRep=0
nFic=0

if (( $# == 0 ))
then 
  read -p "Veuillez saisir le nom du repertoire : " rep
elif (( $# == 1 ))
then
  rep="$1"
else
  echo -e "Erreur: Plus que 1 arguments saisis: $# \n $*"
  echo -e "Usage: $(basename $0) [rep]\n"
  exit 1	
fi

test -d "$rep" || {
  echo -e "Erreur: Le repertoire "$rep" n'existe pas\n"
  exit 1
}

cd $rep
for element in $(ls $rep)
do
  if test -d "$element"
  then
    ((nRep++))
  elif test -f "$element"
  then
    ((nFic++))
  fi
done
cd -

echo -e "Il y a $nFic fichier(s) et $nRep repertoire(s) dans le repertoire $rep.\n"
