#!/bin/bash

# Traitement asynchrone

for i in 1 5 3
do
  (
    echo aa$i
    sleep $i
    echo bb$i
  )&
done
echo "fin"
# attend les processus fils
wait
echo "vrai fin"
