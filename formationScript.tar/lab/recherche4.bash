#!/bin/bash

# Cherche un fichier dans un repertoire

case $# in
  0)
    read -p "Veuillez saisir le nom du repertoire : " rep
    read -p "Veuillez saisir le nom du fichier : " fic
  ;;
  1)
    fic="$1"
    read -p "Veuillez saisir le nom du repertoire : " rep
  ;;
  2)
    fic="$1"
    rep="$2"	
  ;;
  *)
    echo -e "Erreur: Plus que 2 arguments saisis: $# \n$*"
    echo -e "Usage: $(basename $0) [file] [repertory]\n"
    exit 1
  ;;
esac

test -d "$rep" || {
  echo -e "Erreur: Le repertoire "$rep" n'existe pas\n"
  echo -e "Usage: $(basename $0) [file] [repertory]\n"
  exit 1
}

find "$rep" -name "$fic" 2> /dev/null

echo
