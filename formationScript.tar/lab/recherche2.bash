#!/bin/bash

# Cherche un fichier dans un repertoire

read -p "Veuillez saisir le nom du repertoire : " rep

#if ! test -d $rep
#then 
#  echo "Le repertoire $rep n'existe pas"
#  exit 1
#fi

test -d "$rep" || {
  echo "Le repertoire "$rep" n'existe pas"
  exit 1
}

read -p "Veuillez saisir le nom du fichier : " fic

find "$rep" -name "$fic" 
echo $?
