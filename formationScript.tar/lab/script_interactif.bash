#!/bin/bash

# Cherche un fichier dans un repertoire

read -p "Veuillez saisir le nom du repertoire : " rep
read -p "Veuillez saisir le nom du fichier : " fic

find "$rep" -name "$fic"
