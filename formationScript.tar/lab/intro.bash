#!/bin/bash

affichage() {
  clear
  echo "************************"
  echo "*"  
  echo "*        $1"
  echo "*"
  echo "************************"
}
