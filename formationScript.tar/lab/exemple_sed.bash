#!/bin/bash

# Supprime les lignes vides, les commentaires, les espaces et les tabs en trop. Puis inverse les adresses IP et les noms

sed -e '/^[ \t]*$/d' \
    -e '/^#/d' \
    -e 's/#.*//g' \
    -e 's/[ \t][ \t]*/ /g' \
    -e 's/\([0-9.][0-9.]*\) \([a-z0-9][a-z0-9]*\)/\2 \1/g' \
machines
