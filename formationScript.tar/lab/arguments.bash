#!/bin/bash

# Affiche les arguments du script

# Remplace les arguments par le résultat de ls
#set $(ls /etc)

echo "Nom du programme: $0"

echo "Bonjour $2 tu habites à $1"

echo "Nombre d'arguments: $#"

echo "Liste d'arguments: $*"

printf "%10s: %-10s: fin\n" $1 $2

echo
