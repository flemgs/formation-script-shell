#!/bin/bash
# premier script
 
set -x
echo "Je suis l'utilisateur $(whoami) dans le terminal $(tty) sur la machine $(hostname)"
set +x

echo
who

echo
cal

